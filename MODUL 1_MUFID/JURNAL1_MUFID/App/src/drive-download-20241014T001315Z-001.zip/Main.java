import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Membuat objek dari manajemenInventaris

        // Scanner



        // Loop menu list
  
    }
}
