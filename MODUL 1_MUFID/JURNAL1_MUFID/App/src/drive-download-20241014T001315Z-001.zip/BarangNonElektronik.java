public class BarangNonElektronik extends Barang {
    //Atribut

    // Constructor BarangNonElektronik


    // Getter dan Setter untuk material

    // Override method tampilkanData
    @Override
    public void tampilkanData() {
        super.tampilkanData();
        //Tampilan

    }
}
