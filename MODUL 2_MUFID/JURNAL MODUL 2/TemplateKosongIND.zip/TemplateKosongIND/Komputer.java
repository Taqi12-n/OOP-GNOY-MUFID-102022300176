class Komputer {
    // To do: Buatlah 3 variable sesuai ketentuan
    
    // To do: Buatlah constructor pada class Komputer
    
    // To do: Buatlah Method Informasi dengan isi yang sesuai dengan ketentuan 
    // (boleh berbeda dengan output jurnal tetapi dengan cangkupan masih sesuai oleh materi modul!)

}