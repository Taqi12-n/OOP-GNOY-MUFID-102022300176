public class Main {
    public static void main(String[] args) {

        // To do: Buatlah sebuah Objek baru dari class Komputer

        // To do: Panggillah Method Informasi dari class Komputer
        

        System.out.println();


        // To do: Buatlah sebuah Objek baru dari class KomputerVIP 

        // To do: Panggillah Method Informasi dari class KomputerVIP

        // To do: Panggillah Method Login

        // To do: Panggillah Method Bermain 2x agar dapat melakukan polymorphism overloading
        

        System.out.println();


        // To do: Buatlah sebuah Objek baru dari class KomputerPremium

        // To do: Panggillah Method Informasi dari class KomputerPremium

        // To do: Panggillah Method Pesan

        // To do: Panggillah Method TambahLayanan 2x agar dapat melakukan polymorphism overloading
       
    }
}